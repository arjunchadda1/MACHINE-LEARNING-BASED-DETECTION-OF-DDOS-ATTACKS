"""
Verify Flask can reach MySQL with the same settings as app.py.

Usage (project root):
  pip install python-dotenv pymysql
  Copy env.example to .env and set MYSQL_PASSWORD (and other vars if needed)
  python scripts/test_db_connection.py

Or set env vars in the shell instead of using .env.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure project root is on path when run as script
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

try:
    from dotenv import load_dotenv

    load_dotenv(_ROOT / '.env')
except ImportError:
    pass

from sqlalchemy import text

from app import app
from extensions import db


def main() -> int:
    print('Database URI (password hidden):', app.config['SQLALCHEMY_DATABASE_URI'].split('@')[-1])
    try:
        with app.app_context():
            db.session.execute(text('SELECT 1'))
            print('SQLAlchemy ping: OK')
            tables = db.session.execute(text('SHOW TABLES')).fetchall()
            names = [t[0] for t in tables]
            print('Tables in database:', names)
            expected = {'users', 'excel_batches', 'predictions', 'traffic_features'}
            missing = expected - set(names)
            if missing:
                print('WARNING: missing tables:', ', '.join(sorted(missing)))
                print('Run: python scripts/setup_mysql.py')
                return 1
            for t in sorted(expected):
                n = db.session.execute(text(f'SELECT COUNT(*) FROM `{t}`')).scalar()
                print(f'  {t}: {n} rows')
        print('All checks passed.')
        return 0
    except Exception as e:
        print('FAILED:', e, file=sys.stderr)
        print(
            '\nFix: set MYSQL_PASSWORD (copy env.example to .env) or run MySQL and apply mysql/schema.sql.',
            file=sys.stderr,
        )
        return 1


if __name__ == '__main__':
    sys.exit(main())
