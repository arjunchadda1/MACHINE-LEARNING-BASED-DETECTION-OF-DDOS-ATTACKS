"""
Apply mysql/schema.sql to your local MySQL server (creates ddos_netguard + tables).

Usage (PowerShell):
  $env:MYSQL_PASSWORD = "your_root_password"
  python scripts/setup_mysql.py

Optional env vars: MYSQL_HOST (default 127.0.0.1), MYSQL_PORT (3306), MYSQL_USER (root)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

try:
    import pymysql
except ImportError:
    print("Install dependencies: pip install pymysql")
    sys.exit(1)


def _strip_sql_comments(sql: str) -> str:
    out_lines = []
    for line in sql.splitlines():
        s = line.strip()
        if s.startswith("--"):
            continue
        out_lines.append(line)
    return "\n".join(out_lines)


def _split_statements(sql: str) -> list[str]:
    sql = _strip_sql_comments(sql)
    return [c.strip() for c in sql.split(";") if c.strip()]


def main() -> int:
    if "MYSQL_PASSWORD" not in os.environ and not os.environ.get("MYSQL_ALLOW_EMPTY_PASSWORD"):
        print(
            "Set MYSQL_PASSWORD to your MySQL user password, then run again.\n"
            'Example:  $env:MYSQL_PASSWORD = "yourpassword"\n'
            "Empty password:  $env:MYSQL_PASSWORD = \"\"  and  $env:MYSQL_ALLOW_EMPTY_PASSWORD = \"1\"",
            file=sys.stderr,
        )
        return 1

    host = os.environ.get("MYSQL_HOST", "127.0.0.1")
    port = int(os.environ.get("MYSQL_PORT", "3306"))
    user = os.environ.get("MYSQL_USER", "root")
    password = os.environ.get("MYSQL_PASSWORD", "")

    root = Path(__file__).resolve().parents[1]
    schema_path = root / "mysql" / "schema.sql"
    if not schema_path.is_file():
        print(f"Missing {schema_path}", file=sys.stderr)
        return 1

    sql_text = schema_path.read_text(encoding="utf-8")
    statements = _split_statements(sql_text)
    if not statements:
        print("No SQL statements found in schema.sql", file=sys.stderr)
        return 1

    try:
        conn = pymysql.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            charset="utf8mb4",
            autocommit=True,
        )
    except pymysql.err.OperationalError as e:
        print(f"Could not connect to MySQL at {host}:{port} as {user}: {e}", file=sys.stderr)
        return 1

    try:
        with conn.cursor() as cur:
            for i, stmt in enumerate(statements, 1):
                cur.execute(stmt)
        print(f"OK: ran {len(statements)} statements from {schema_path.name}")
        print("Database: ddos_netguard — tables: users, excel_batches, predictions, traffic_features")
    except Exception as e:
        print(f"Error executing statement: {e}", file=sys.stderr)
        return 1
    finally:
        conn.close()

    return 0


if __name__ == "__main__":
    sys.exit(main())
