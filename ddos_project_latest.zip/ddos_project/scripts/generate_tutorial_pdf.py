"""
Build SETUP_AND_DATABASE_TUTORIAL.pdf from SETUP_AND_DATABASE_TUTORIAL.md (ReportLab).

Usage (project root):
  pip install reportlab
  python scripts/generate_tutorial_pdf.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
)
from xml.sax.saxutils import escape as xml_escape

ROOT = Path(__file__).resolve().parents[1]
MD_PATH = ROOT / 'SETUP_AND_DATABASE_TUTORIAL.md'
PDF_PATH = ROOT / 'SETUP_AND_DATABASE_TUTORIAL.pdf'


def _inline_md_to_reportlab(s: str) -> str:
    """Convert **bold** and `code` to ReportLab XML subset."""
    s = xml_escape(s)
    s = re.sub(r'\*\*(.+?)\*\*', lambda m: f'<b>{m.group(1)}</b>', s)
    s = re.sub(r'`([^`]+)`', r'<font name="Courier" size="9">\1</font>', s)
    return s


def md_to_story(md: str) -> list:
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        name='DocTitle',
        parent=styles['Heading1'],
        fontSize=16,
        spaceAfter=12,
        textColor=colors.HexColor('#0f172a'),
    )
    h2 = ParagraphStyle(
        name='H2',
        parent=styles['Heading2'],
        fontSize=13,
        spaceBefore=14,
        spaceAfter=8,
        textColor=colors.HexColor('#1e3a5f'),
    )
    h3 = ParagraphStyle(
        name='H3',
        parent=styles['Heading3'],
        fontSize=11,
        spaceBefore=10,
        spaceAfter=6,
    )
    code_style = ParagraphStyle(
        name='CodeBlock',
        parent=styles['Code'],
        fontName='Courier',
        fontSize=8,
        leftIndent=12,
        backColor=colors.HexColor('#f1f5f9'),
        borderColor=colors.HexColor('#cbd5e1'),
        borderWidth=0.5,
        borderPadding=6,
    )
    small = ParagraphStyle(
        name='Small',
        parent=styles['Normal'],
        fontSize=8,
        leading=10,
    )

    story: list = []
    lines = md.splitlines()
    i = 0
    in_code = False
    code_lines: list[str] = []

    while i < len(lines):
        line = lines[i]
        raw = line.rstrip('\n')

        if raw.strip().startswith('```'):
            if in_code:
                block = '\n'.join(code_lines)
                story.append(Preformatted(block, code_style))
                story.append(Spacer(1, 8))
                code_lines = []
                in_code = False
            else:
                in_code = True
            i += 1
            continue

        if in_code:
            code_lines.append(line)
            i += 1
            continue

        if raw.strip() == '---':
            story.append(Spacer(1, 10))
            i += 1
            continue

        if not raw.strip():
            story.append(Spacer(1, 4))
            i += 1
            continue

        if raw.startswith('# '):
            story.append(Paragraph(_inline_md_to_reportlab(raw[2:].strip()), title))
        elif raw.startswith('## '):
            story.append(Paragraph(_inline_md_to_reportlab(raw[3:].strip()), h2))
        elif raw.startswith('### '):
            story.append(Paragraph(_inline_md_to_reportlab(raw[4:].strip()), h3))
        elif raw.startswith('|'):
            story.append(Paragraph(_inline_md_to_reportlab(raw.replace('|', ' | ')), small))
        elif raw.startswith('- '):
            story.append(Paragraph('• ' + _inline_md_to_reportlab(raw[2:].strip()), styles['Normal']))
        elif raw.startswith('> '):
            story.append(
                Paragraph(
                    '<i>' + _inline_md_to_reportlab(raw[2:].strip()) + '</i>',
                    styles['Normal'],
                )
            )
        else:
            story.append(Paragraph(_inline_md_to_reportlab(raw), styles['Normal']))
        i += 1

    return story


def main() -> int:
    if not MD_PATH.is_file():
        print('Missing', MD_PATH, file=sys.stderr)
        return 1
    md = MD_PATH.read_text(encoding='utf-8')
    story = md_to_story(md)
    doc = SimpleDocTemplate(
        str(PDF_PATH),
        pagesize=A4,
        rightMargin=2 * cm,
        leftMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        title='NetGuard AI — Setup and database tutorial',
        author='ddos_project',
    )
    doc.build(story)
    print('Wrote:', PDF_PATH)
    return 0


if __name__ == '__main__':
    sys.exit(main())
