-- =============================================================================
-- NetGuard AI / DDoS Detection — MySQL schema for MySQL Workbench
-- Server: MySQL 8.0+ recommended (utf8mb4, InnoDB)
-- =============================================================================
-- In Workbench: File → Open SQL Script → select this file → Execute (⚡)
-- Creates database `ddos_netguard` and all tables. Drops existing tables in
-- that database only (not other databases).
-- =============================================================================

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS ddos_netguard
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ddos_netguard;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS traffic_features;
DROP TABLE IF EXISTS predictions;
DROP TABLE IF EXISTS excel_batches;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------------------------------
-- Users (authentication)
-- -----------------------------------------------------------------------------
CREATE TABLE users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username      VARCHAR(80) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- Bulk Excel uploads (one row per file processed)
-- -----------------------------------------------------------------------------
CREATE TABLE excel_batches (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id           INT UNSIGNED NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  row_count         INT UNSIGNED NOT NULL,
  uploaded_at       DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_excel_batches_user (user_id),
  CONSTRAINT fk_excel_batches_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- Predictions (manual single row or one row per Excel line)
-- -----------------------------------------------------------------------------
CREATE TABLE predictions (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id          INT UNSIGNED NOT NULL,
  excel_batch_id   INT UNSIGNED NULL COMMENT 'NULL for manual input',
  excel_row_num    INT UNSIGNED NULL COMMENT 'Excel data row index; NULL for manual (not named row_number: reserved in MySQL 8+)',
  input_source     ENUM('manual','excel') NOT NULL,
  predicted_label  ENUM('Normal','DDoS','Error') NOT NULL,
  error_message    TEXT NULL,
  created_at       DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_predictions_user_created (user_id, created_at),
  KEY idx_predictions_batch (excel_batch_id),
  CONSTRAINT fk_predictions_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_predictions_batch
    FOREIGN KEY (excel_batch_id) REFERENCES excel_batches (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- Traffic feature vector (1:1 with successful predictions)
-- -----------------------------------------------------------------------------
CREATE TABLE traffic_features (
  prediction_id BIGINT UNSIGNED NOT NULL,
  switch        DECIMAL(24,6) NULL,
  pktcount      DECIMAL(24,6) NULL,
  bytecount     DECIMAL(24,6) NULL,
  dur           DECIMAL(24,6) NULL,
  dur_nsec      DECIMAL(24,6) NULL,
  flows         DECIMAL(24,6) NULL,
  pktrate       DECIMAL(24,6) NULL,
  pairflow      DECIMAL(24,6) NULL,
  port_no       DECIMAL(24,6) NULL,
  tx_bytes      DECIMAL(24,6) NULL,
  rx_bytes      DECIMAL(24,6) NULL,
  tx_kbps       DECIMAL(24,6) NULL,
  rx_kbps       DECIMAL(24,6) NULL,
  PRIMARY KEY (prediction_id),
  CONSTRAINT fk_traffic_features_prediction
    FOREIGN KEY (prediction_id) REFERENCES predictions (id)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
