NetGuard AI — MySQL setup (MySQL Workbench)
============================================

1) Start MySQL Server (local or remote).

--- Option A: command line (from project root folder) ---

   pip install pymysql
   $env:MYSQL_PASSWORD = "your_mysql_password"
   python scripts/setup_mysql.py

   This runs the same SQL as Workbench and prints OK when finished.

--- Option B: MySQL Workbench ---

2) Open MySQL Workbench and connect to your server.

3) File → Open SQL Script → select `schema.sql` in this folder.

4) Execute the full script (toolbar lightning bolt). This creates:
   - Database: `ddos_netguard`
   - Tables: `users`, `excel_batches`, `predictions`, `traffic_features`

5) Create a MySQL user (optional) or use `root`:
   - Note the username and password for your connection.

6) Configure the Flask app using environment variables (PowerShell example):

   $env:MYSQL_USER="root"
   $env:MYSQL_PASSWORD="yourpassword"
   $env:MYSQL_HOST="127.0.0.1"
   $env:MYSQL_PORT="3306"
   $env:MYSQL_DATABASE="ddos_netguard"

   Or set a single URL:

   $env:DATABASE_URL="mysql+pymysql://root:yourpassword@127.0.0.1:3306/ddos_netguard?charset=utf8mb4"

7) Install Python dependencies (from project root):

   pip install -r requirements.txt

8) Run the app:

   python app.py

Re-running `schema.sql` drops and recreates tables inside `ddos_netguard` only (all data in those tables is erased).
