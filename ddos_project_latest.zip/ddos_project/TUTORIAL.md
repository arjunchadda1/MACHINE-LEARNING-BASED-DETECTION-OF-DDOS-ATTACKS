# Tutorial: Run NetGuard AI (DDoS Detection)

This guide walks you through running the Flask app on **Windows**, **macOS**, or **Linux** from a fresh copy of the project.

**Full plan (MySQL, `.env`, SQL queries):** see **`SETUP_AND_DATABASE_TUTORIAL.md`** in the same folder.

---

## What you need

| Requirement | Notes |
|-------------|--------|
| **Python** | Version **3.9 or newer** recommended (3.10+ works well). Check with `python --version` or `python3 --version`. |
| **Internet** | Only needed once, to `pip install` packages from PyPI. |
| **Project files** | Folder containing `app.py`, `requirements.txt`, `ddos.sav`, `templates/`, etc. |

---

## Step 1: Open a terminal in the project folder

1. Unzip the project if you received a `.zip` archive (you should see `app.py` at the top level of the folder).
2. Open **Command Prompt**, **PowerShell**, or **Terminal**.
3. Change into that folder, for example:

```powershell
cd path\to\ddos_project
```

Use the real path where you placed the project (on Windows, quotes help if the path has spaces: `cd "C:\Users\You\Downloads\ddos_project"`).

---

## Step 2 (optional): Use a virtual environment

Keeps dependencies isolated from other Python projects.

**Windows (PowerShell):**

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**macOS / Linux:**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

After activation, your prompt usually shows `(.venv)`.

---

## Step 3: Install Python dependencies

From the project folder (with the venv activated if you use one):

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

This installs **Flask**, **pandas**, **openpyxl**, **numpy**, and **scikit-learn**.

---

## Step 4: Ensure the model file exists

The app loads **`ddos.sav`** when it starts. If that file is already in the project folder, skip to Step 5.

If **`ddos.sav` is missing** but you have **`dataset_sdn.csv`** and **`train_model.py`**, generate the model:

```bash
python train_model.py
```

You should see a message that the model was saved to `ddos.sav`. Then continue.

---

## Step 5: Start the web server

```bash
python app.py
```

You should see output similar to:

```text
 * Running on http://127.0.0.1:5000
```

Leave this terminal window open while you use the app. To stop the server, press **Ctrl+C**.

---

## Step 6: Open the app in your browser

| URL | What it is |
|-----|------------|
| [http://127.0.0.1:5000](http://127.0.0.1:5000) | Home page |
| [http://127.0.0.1:5000/register](http://127.0.0.1:5000/register) | Create an account (stored in memory for this session only) |
| [http://127.0.0.1:5000/login](http://127.0.0.1:5000/login) | Log in |
| [http://127.0.0.1:5000/predict](http://127.0.0.1:5000/predict) | **NetGuard dashboard** — only after you log in (see below) |
| [http://127.0.0.1:5000/logout](http://127.0.0.1:5000/logout) | Log out (ends your session; you must log in again for the dashboard) |

**Typical flow:**

1. Open **Home** → **Register** (choose username and password) → you are sent to **Login**.
2. **Login** with the same credentials → you are redirected to **`/predict`** (NetGuard dashboard).
3. If you open **`/predict`** or **Suggestions** without being logged in, the app sends you to **Login** first.
4. Use **Dashboard** for metrics and live feed, **Manual Analysis** for single-row classification, **Bulk Upload** for `.xlsx` / `.xls` batches. Use **Log out** in the top bar when finished.

**Note:** User accounts are stored **in memory** only. If you **restart** the `python app.py` process, registered users are cleared and you must register again.

---

## Quick reference commands

```bash
# Install deps
python -m pip install -r requirements.txt

# Train model (only if ddos.sav is missing)
python train_model.py

# Run app
python app.py
```

---

## Troubleshooting

### `python` is not recognized

Try `py` on Windows (`py -m pip install -r requirements.txt`), or install Python from [python.org](https://www.python.org/downloads/) and enable **“Add Python to PATH”**.

### `No module named 'flask'` (or similar)

Run `pip install` from **inside the project folder**, and use the same Python you use to run `app.py`:

```bash
python -m pip install -r requirements.txt
```

### `ddos.sav` not found

Run `python train_model.py` with `dataset_sdn.csv` present, or restore `ddos.sav` from a full project copy.

### Port 5000 already in use

Another program (or a second copy of this app) is using port 5000. Close the other process, or change the port at the bottom of `app.py`, for example:

```python
app.run(debug=True, port=5001)
```

Then open `http://127.0.0.1:5001`.

### Excel upload errors

Use the template from **Bulk Upload → Download template**. Column names must match the expected traffic fields (case-insensitive). Max upload size is set in `app.py` (default 16 MB).

---

## Security note

This project runs Flask’s **development** server with **debug** enabled in `app.py`. That is fine for **local learning and demos**. Do **not** expose it to the public internet without hardening (production WSGI server, HTTPS, real user storage, secrets, etc.).

---

## Project layout (short)

| File / folder | Role |
|---------------|------|
| `app.py` | Main Flask application |
| `ddos.sav` | Trained classifier (loaded at startup) |
| `train_model.py` | Retrain and save `ddos.sav` from `dataset_sdn.csv` |
| `requirements.txt` | Python dependencies |
| `templates/` | HTML (NetGuard UI, login, etc.) |

If anything fails, copy the **full error message** from the terminal and check that your current directory is the folder that contains `app.py`.
