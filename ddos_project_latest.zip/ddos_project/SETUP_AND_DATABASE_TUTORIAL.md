# Full tutorial plan: run the project, use MySQL, and query data

This document is a **step-by-step plan** you can follow on **Windows** (adjust paths for macOS/Linux). It covers: environment setup, database creation, running Flask, using the app, and **reading data with SQL** in MySQL Workbench (or any MySQL client).

---

## Part A — Prerequisites checklist

| Step | What to install / verify |
|------|---------------------------|
| A1 | **Python 3.9+** — `python --version` in PowerShell |
| A2 | **MySQL Server** — service running (e.g. **MySQL96** in `services.msc`) |
| A3 | **MySQL Workbench** (optional but recommended for queries and running `schema.sql`) |
| A4 | Project folder with **`app.py`**, **`requirements.txt`**, **`ddos.sav`**, **`mysql/schema.sql`**, templates |

---

## Part B — MySQL server and database schema

### B1. Start MySQL

- Open **Services** (`Win + R` → `services.msc`) and ensure your MySQL service (e.g. **MySQL96**) is **Running**.

### B2. Create tables (choose one method)

**Method 1 — MySQL Workbench**

1. Connect to `127.0.0.1:3306` with your MySQL user (often `root`).
2. **File → Open SQL Script** → open `mysql/schema.sql`.
3. Execute the **entire** script (lightning icon).  
   This creates database **`ddos_netguard`** and tables: **`users`**, **`excel_batches`**, **`predictions`**, **`traffic_features`**.

**Method 2 — Command line (from project root)**

```powershell
pip install pymysql
$env:MYSQL_PASSWORD = "YOUR_MYSQL_PASSWORD"
python scripts\setup_mysql.py
```

> Re-running the full `schema.sql` **drops and recreates** those tables — existing rows are deleted.

### B3. Understand what each table stores

| Table | Purpose |
|-------|---------|
| **users** | Registered accounts (`username`, `password_hash`, `created_at`). |
| **excel_batches** | One row per uploaded Excel file (`original_filename`, `row_count`, `uploaded_at`). |
| **predictions** | One row per classification: manual submit or one Excel row (`input_source`, `predicted_label`, `excel_batch_id`, `excel_row_num`, `error_message` if failed). |
| **traffic_features** | The 13 traffic numbers for that prediction (`prediction_id` = FK to `predictions.id`). |

Relationships:

- `users` → many `excel_batches` and many `predictions`.
- `excel_batches` → many `predictions` (bulk rows).
- `predictions` → at most one `traffic_features` (none for some error-only rows, depending on app behavior).

---

## Part C — Configure the Flask app (`.env`)

### C1. Create `.env` in the **project root** (same folder as `app.py`)

Copy `env.example` to `.env` and edit:

```ini
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=YOUR_PASSWORD_HERE
MYSQL_DATABASE=ddos_netguard
```

Save the file. **`app.py` loads `.env` automatically** via `python-dotenv` (do not commit `.env` to Git; it is in `.gitignore`).

### C2. Install Python dependencies

```powershell
cd "C:\path\to\your\ddos_project_folder"
python -m pip install -r requirements.txt
```

### C3. Verify database connectivity

```powershell
python scripts\test_db_connection.py
```

You should see **SQLAlchemy ping: OK** and the four tables listed. If not, fix `MYSQL_*` in `.env` or confirm MySQL is running.

---

## Part D — Run the web application

```powershell
python app.py
```

Open a browser:

| URL | Purpose |
|-----|---------|
| http://127.0.0.1:5000 | Home |
| http://127.0.0.1:5000/register | Create account |
| http://127.0.0.1:5000/login | Sign in |
| http://127.0.0.1:5000/predict | NetGuard dashboard (after login) |

**Typical flow:** Register → Login → **Dashboard** / **Manual Analysis** / **Bulk Upload**.  
Predictions are **saved to MySQL** for the logged-in user.

Stop the server: **Ctrl+C** in the terminal.

---

## Part E — How the app uses the database (mental model)

1. **Register** → inserts a row into **`users`** (hashed password).
2. **Login** → reads **`users`**, sets Flask **session** (`user_id`, username).
3. **Manual prediction** → inserts **`predictions`** + **`traffic_features`**.
4. **Bulk Excel** → inserts **`excel_batches`**, then one **`predictions`** row per sheet row (+ **`traffic_features`** when successful).

The dashboard reads **aggregates and recent rows** via SQLAlchemy in `db_helpers.py` (filtered by **your** `user_id`).

---

## Part F — Fetch and inspect data with SQL (MySQL Workbench)

In Workbench, select schema **`ddos_netguard`** or prefix tables as `ddos_netguard.table_name`.

### F1. List tables and sizes

```sql
USE ddos_netguard;

SHOW TABLES;

SELECT 'users' AS tbl, COUNT(*) AS n FROM users
UNION ALL SELECT 'excel_batches', COUNT(*) FROM excel_batches
UNION ALL SELECT 'predictions', COUNT(*) FROM predictions
UNION ALL SELECT 'traffic_features', COUNT(*) FROM traffic_features;
```

### F2. See registered users (no password hashes in screenshots)

```sql
SELECT id, username, created_at FROM users;
```

### F3. Recent predictions (who, what label, when)

```sql
SELECT
  p.id,
  u.username,
  p.input_source,
  p.predicted_label,
  p.excel_row_num,
  p.created_at
FROM predictions p
JOIN users u ON u.id = p.user_id
ORDER BY p.created_at DESC
LIMIT 50;
```

### F4. Predictions with traffic numbers (join)

```sql
SELECT
  p.id,
  u.username,
  p.predicted_label,
  tf.port_no,
  tf.pktrate,
  tf.flows,
  tf.rx_kbps
FROM predictions p
JOIN users u ON u.id = p.user_id
LEFT JOIN traffic_features tf ON tf.prediction_id = p.id
ORDER BY p.created_at DESC
LIMIT 30;
```

### F5. Bulk uploads metadata

```sql
SELECT
  b.id,
  u.username,
  b.original_filename,
  b.row_count,
  b.uploaded_at
FROM excel_batches b
JOIN users u ON u.id = b.user_id
ORDER BY b.uploaded_at DESC;
```

### F6. Count DDoS vs Normal for one user (by username)

```sql
SELECT p.predicted_label, COUNT(*) AS cnt
FROM predictions p
JOIN users u ON u.id = p.user_id
WHERE u.username = 'YOUR_USERNAME'
  AND p.predicted_label IN ('Normal', 'DDoS')
GROUP BY p.predicted_label;
```

Replace `'YOUR_USERNAME'` with the account you created in the app.

### F7. Export-style: all columns from `traffic_features` for last 20 predictions

```sql
SELECT p.id AS prediction_id, u.username, p.predicted_label, p.created_at, tf.*
FROM predictions p
JOIN users u ON u.id = p.user_id
LEFT JOIN traffic_features tf ON tf.prediction_id = p.id
ORDER BY p.created_at DESC
LIMIT 20;
```

---

## Part G — Troubleshooting

| Problem | What to try |
|---------|-------------|
| `Access denied` for MySQL | Fix `MYSQL_PASSWORD` in `.env`; confirm user exists in MySQL. |
| `Unknown database 'ddos_netguard'` | Run `mysql/schema.sql` or `scripts/setup_mysql.py`. |
| Workbench “can’t connect” | Ensure MySQL **service** is Running; host `127.0.0.1`, port `3306`. |
| Flask works but dashboard empty | Log in and run at least one prediction; then re-run SQL counts. |
| Port 5000 in use | Change `app.run(..., port=5001)` in `app.py` or close the other app. |

---

## Part H — Security and coursework notes

- Use **development** mode only on your own PC; do not expose `debug=True` to the internet.
- Do **not** commit **`.env`** or share **passwords** in screenshots or reports.
- For assignments, you can paste **sample SQL results** (with usernames anonymized if required).

---

## Quick command reference

```powershell
# Project folder
cd "C:\path\to\ddos_project"

# Dependencies
python -m pip install -r requirements.txt

# Test DB
python scripts\test_db_connection.py

# Run app
python app.py
```

For more on basic Flask run steps (venv, training `ddos.sav` if missing), see **`TUTORIAL.md`**.

---

## PDF copy

A printable PDF can be generated from this file with:

```powershell
pip install reportlab
python scripts\generate_tutorial_pdf.py
```

Output: **`SETUP_AND_DATABASE_TUTORIAL.pdf`** in the project folder (next to `app.py`).
