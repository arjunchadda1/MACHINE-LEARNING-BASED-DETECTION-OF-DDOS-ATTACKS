from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load pre-trained model
model = pickle.load(open('ddos.sav', 'rb'))

# Track prediction results
prediction_counts = {'Normal': 0, 'DDoS': 0}
traffic_over_time = []

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/predict', methods=['GET', 'POST'])
def prediction():
    global prediction_counts, traffic_over_time

    prediction_result = None
    fields = ['switch', 'pktcount', 'bytecount', 'dur', 'dur_nsec', 'flows',
              'pktrate', 'Pairflow', 'port_no', 'tx_bytes', 'rx_bytes', 'tx_kbps', 'rx_kbps']
    
    if request.method == 'POST':
        try:
            input_data = [float(request.form.get(field, 0)) for field in fields]
            pred = model.predict([input_data])[0]
            label = "DDoS" if pred == 1 else "Normal"
            prediction_result = "🔴 DDoS Attack Detected" if label == "DDoS" else "🟢 Normal Traffic"

            prediction_counts[label] += 1
            traffic_over_time.append(input_data[-1])  # rx_kbps
        except Exception as e:
            prediction_result = f"⚠️ Error: {str(e)}"

    return render_template('prediction.html', prediction=prediction_result)

if __name__ == '__main__':
    app.run(debug=True)
