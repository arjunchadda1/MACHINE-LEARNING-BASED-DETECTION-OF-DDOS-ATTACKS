from datetime import datetime

from extensions import db


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    predictions = db.relationship('Prediction', backref='user', lazy='dynamic')
    excel_batches = db.relationship('ExcelBatch', backref='user', lazy='dynamic')


class ExcelBatch(db.Model):
    __tablename__ = 'excel_batches'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    row_count = db.Column(db.Integer, nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    predictions = db.relationship('Prediction', backref='excel_batch', lazy='dynamic')


class Prediction(db.Model):
    __tablename__ = 'predictions'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    excel_batch_id = db.Column(db.Integer, db.ForeignKey('excel_batches.id', ondelete='SET NULL'), nullable=True)
    excel_row_num = db.Column(db.Integer, nullable=True)
    input_source = db.Column(db.String(20), nullable=False)
    predicted_label = db.Column(db.String(20), nullable=False)
    error_message = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    features = db.relationship(
        'TrafficFeature',
        backref='prediction',
        uselist=False,
        cascade='all, delete-orphan',
    )


class TrafficFeature(db.Model):
    __tablename__ = 'traffic_features'

    prediction_id = db.Column(
        db.BigInteger,
        db.ForeignKey('predictions.id', ondelete='CASCADE'),
        primary_key=True,
    )
    switch = db.Column(db.Numeric(24, 6))
    pktcount = db.Column(db.Numeric(24, 6))
    bytecount = db.Column(db.Numeric(24, 6))
    dur = db.Column(db.Numeric(24, 6))
    dur_nsec = db.Column(db.Numeric(24, 6))
    flows = db.Column(db.Numeric(24, 6))
    pktrate = db.Column(db.Numeric(24, 6))
    pairflow = db.Column(db.Numeric(24, 6))
    port_no = db.Column(db.Numeric(24, 6))
    tx_bytes = db.Column(db.Numeric(24, 6))
    rx_bytes = db.Column(db.Numeric(24, 6))
    tx_kbps = db.Column(db.Numeric(24, 6))
    rx_kbps = db.Column(db.Numeric(24, 6))
