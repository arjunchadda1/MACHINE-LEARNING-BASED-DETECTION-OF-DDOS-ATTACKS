"""Train and save the DDoS detection model. Run this if ddos.sav doesn't exist."""
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

FEATURES = ['switch', 'pktcount', 'bytecount', 'dur', 'dur_nsec', 'flows',
            'pktrate', 'Pairflow', 'port_no', 'tx_bytes', 'rx_bytes', 'tx_kbps', 'rx_kbps']

data = pd.read_csv('dataset_sdn.csv')
X = data[FEATURES].fillna(0)
y = data['label']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
model = RandomForestClassifier(n_estimators=10, random_state=42)
model.fit(X_train, y_train)

import pickle
pickle.dump(model, open('ddos.sav', 'wb'))
print(f"Model saved to ddos.sav (accuracy: {model.score(X_test, y_test):.2%})")
