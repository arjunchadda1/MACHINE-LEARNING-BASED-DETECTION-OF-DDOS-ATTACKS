"""Persistence and dashboard queries for MySQL-backed predictions."""

from extensions import db
from models import ExcelBatch, Prediction, TrafficFeature


def _field_to_column(field):
    return 'pairflow' if field == 'Pairflow' else field.lower()


def traffic_feature_from_prediction_id(prediction_id, features, required_fields):
    tf = TrafficFeature(prediction_id=prediction_id)
    for f in required_fields:
        col = _field_to_column(f)
        val = features.get(f, 0)
        setattr(tf, col, val)
    return tf


def persist_manual_prediction(user_id, label, features, required_fields):
    try:
        p = Prediction(
            user_id=user_id,
            excel_batch_id=None,
            excel_row_num=None,
            input_source='manual',
            predicted_label=label,
            error_message=None,
        )
        db.session.add(p)
        db.session.flush()
        if label != 'Error' and features:
            db.session.add(traffic_feature_from_prediction_id(p.id, features, required_fields))
        db.session.commit()
        return p
    except Exception:
        db.session.rollback()
        raise


def persist_excel_batch(user_id, original_filename, results, required_fields):
    try:
        batch = ExcelBatch(
            user_id=user_id,
            original_filename=original_filename,
            row_count=len(results),
        )
        db.session.add(batch)
        db.session.flush()
        for r in results:
            lbl = r['label']
            p = Prediction(
                user_id=user_id,
                excel_batch_id=batch.id,
                excel_row_num=r['row'],
                input_source='excel',
                predicted_label=lbl,
                error_message=r.get('error'),
            )
            db.session.add(p)
            db.session.flush()
            if lbl != 'Error' and r.get('features'):
                db.session.add(traffic_feature_from_prediction_id(p.id, r['features'], required_fields))
        db.session.commit()
        return batch
    except Exception:
        db.session.rollback()
        raise


def get_dashboard_data(user_id):
    ddos_n = Prediction.query.filter_by(user_id=user_id, predicted_label='DDoS').count()
    normal_n = Prediction.query.filter_by(user_id=user_id, predicted_label='Normal').count()
    threat_total = ddos_n + normal_n
    total_scans = threat_total
    ddos_share = (100.0 * ddos_n / threat_total) if threat_total else 0.0
    normal_share = (100.0 * normal_n / threat_total) if threat_total else 0.0
    ddos_rate_pct = ddos_share
    ddos_deg = min(360.0, max(0.0, ddos_share * 3.6))

    recent_rows = []
    preds = (
        Prediction.query.filter(
            Prediction.user_id == user_id,
            Prediction.predicted_label.in_(['Normal', 'DDoS']),
        )
        .order_by(Prediction.created_at.desc())
        .limit(15)
        .all()
    )
    for p in preds:
        tf = TrafficFeature.query.get(p.id)
        if not tf:
            continue
        recent_rows.append(
            {
                'timestamp': p.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'source_port': float(tf.port_no or 0),
                'packet_rate': float(tf.pktrate or 0),
                'flows': float(tf.flows or 0),
                'status': p.predicted_label,
            }
        )

    return {
        'prediction_counts': {'DDoS': ddos_n, 'Normal': normal_n},
        'threat_total': threat_total,
        'total_scans': total_scans,
        'ddos_share': round(ddos_share, 1),
        'normal_share': round(normal_share, 1),
        'ddos_rate_pct': round(ddos_rate_pct, 1),
        'ddos_deg': ddos_deg,
        'recent_rows': recent_rows,
    }
