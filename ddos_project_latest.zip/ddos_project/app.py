import math
import os

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

from functools import wraps
from urllib.parse import quote_plus

import io
import pickle

import numpy as np
import pandas as pd
from flask import Flask, render_template, request, redirect, session, url_for, send_file
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from db_helpers import get_dashboard_data, persist_excel_batch, persist_manual_prediction
from extensions import db
from models import User

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'


@app.template_filter('fmt_metric')
def fmt_metric(value):
    """Format numeric metrics for display: thousands separators, trim trailing zeros."""
    if value is None:
        return '—'
    try:
        x = float(value)
        if math.isnan(x):
            return '—'
        ax = abs(x)
        if ax >= 1e12:
            return f'{x:.4e}'
        if abs(x - round(x)) < 1e-7:
            return f'{int(round(x)):,}'
        s = f'{x:,.6f}'.rstrip('0').rstrip('.')
        return s
    except (TypeError, ValueError):
        return str(value)


def _database_uri():
    if os.environ.get('DATABASE_URL'):
        return os.environ['DATABASE_URL']
    u = os.environ.get('MYSQL_USER', 'root')
    p = os.environ.get('MYSQL_PASSWORD', '')
    h = os.environ.get('MYSQL_HOST', '127.0.0.1')
    port = os.environ.get('MYSQL_PORT', '3306')
    d = os.environ.get('MYSQL_DATABASE', 'ddos_netguard')
    return f'mysql+pymysql://{u}:{quote_plus(p)}@{h}:{port}/{d}?charset=utf8mb4'


app.config['SQLALCHEMY_DATABASE_URI'] = _database_uri()
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your_secret_key')

db.init_app(app)

model = pickle.load(open('ddos.sav', 'rb'))

ACTIVE_SENSORS = 14

REQUIRED_FIELDS = [
    'switch', 'pktcount', 'bytecount', 'dur', 'dur_nsec', 'flows',
    'pktrate', 'Pairflow', 'port_no', 'tx_bytes', 'rx_bytes', 'tx_kbps', 'rx_kbps',
]


def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login'))
        return view(*args, **kwargs)

    return wrapped_view


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if session.get('user_id'):
        return redirect(url_for('prediction'))
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        if not username or not password:
            return render_template('register.html', error='Username and password are required.')
        if User.query.filter_by(username=username).first():
            return render_template('register.html', error='That username is already taken.')
        user = User(username=username, password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('user_id'):
        return redirect(url_for('prediction'))
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        password = request.form.get('password') or ''
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['user'] = user.username
            return redirect(url_for('prediction'))
        return render_template('login.html', error='Invalid username or password.')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user', None)
    return redirect(url_for('home'))


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'xlsx', 'xls'}


def parse_excel_and_predict(filepath):
    """Read Excel and return per-row predictions with feature snapshots (no DB)."""
    df = pd.read_excel(filepath)
    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
    results = []
    for idx, row in df.iterrows():
        try:
            input_data = []
            for field in REQUIRED_FIELDS:
                col = next((c for c in df.columns if c.lower() == field.lower()), None)
                val = row[col] if col is not None and col in row.index else 0
                input_data.append(float(val) if pd.notna(val) else 0)
            pred = model.predict([input_data])[0]
            label = 'DDoS' if pred == 1 else 'Normal'
            features = dict(zip(REQUIRED_FIELDS, input_data))
            results.append({'row': idx + 1, 'label': label, 'features': features})
        except Exception as e:
            results.append({'row': idx + 1, 'label': 'Error', 'error': str(e), 'features': {}})
    return results


@app.route('/predict', methods=['GET', 'POST'])
@login_required
def prediction():
    uid = session['user_id']
    prediction_result = None
    excel_results = None
    manual_snapshot = None

    if request.method == 'POST':
        file = request.files.get('excel_file')
        if file and file.filename:
            if allowed_file(file.filename):
                try:
                    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
                    safe_name = secure_filename(file.filename)
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], safe_name)
                    file.save(filepath)
                    excel_results = parse_excel_and_predict(filepath)
                    os.remove(filepath)
                    try:
                        persist_excel_batch(uid, safe_name or file.filename, excel_results, REQUIRED_FIELDS)
                    except Exception as db_exc:
                        db.session.rollback()
                        prediction_result = f'⚠️ Could not save results to database: {db_exc}'
                    else:
                        ddos_count = sum(1 for r in excel_results if r['label'] == 'DDoS')
                        normal_count = sum(1 for r in excel_results if r['label'] == 'Normal')
                        prediction_result = (
                            f'Processed {len(excel_results)} rows: {ddos_count} DDoS, {normal_count} Normal'
                        )
                except Exception as e:
                    prediction_result = f'⚠️ Error reading Excel: {str(e)}'
            else:
                prediction_result = '⚠️ Invalid file. Please upload .xlsx or .xls file.'
        else:
            try:
                input_data = [float(request.form.get(field, 0)) for field in REQUIRED_FIELDS]
                pred = model.predict([input_data])[0]
                label = 'DDoS' if pred == 1 else 'Normal'
                prediction_result = '🔴 DDoS Attack Detected' if label == 'DDoS' else '🟢 Normal Traffic'
                manual_snapshot = {
                    'label': label,
                    'features': dict(zip(REQUIRED_FIELDS, input_data)),
                }
                try:
                    persist_manual_prediction(uid, label, manual_snapshot['features'], REQUIRED_FIELDS)
                except Exception as db_exc:
                    db.session.rollback()
                    prediction_result = f'⚠️ Could not save to database: {db_exc}'
            except Exception as e:
                prediction_result = f'⚠️ Error: {str(e)}'

    dash = get_dashboard_data(uid)
    active_tab = 'dashboard'
    if request.method == 'POST':
        f = request.files.get('excel_file')
        if f and f.filename:
            active_tab = 'bulk'
        else:
            active_tab = 'manual'

    return render_template(
        'prediction.html',
        prediction=prediction_result,
        excel_results=excel_results,
        manual_snapshot=manual_snapshot,
        required_fields=REQUIRED_FIELDS,
        recent_rows=dash['recent_rows'],
        prediction_counts=dash['prediction_counts'],
        total_scans=dash['total_scans'],
        threat_total=dash['threat_total'],
        ddos_share=dash['ddos_share'],
        normal_share=dash['normal_share'],
        ddos_rate_pct=dash['ddos_rate_pct'],
        ddos_deg=dash['ddos_deg'],
        active_sensors=ACTIVE_SENSORS,
        active_tab=active_tab,
    )


@app.route('/predict/template')
@login_required
def download_template():
    df = pd.DataFrame(columns=REQUIRED_FIELDS)
    df.loc[0] = [1, 45304, 48294064, 100, 716000000, 3, 451, 0, 3, 143928631, 3917, 0, 0]
    buffer = io.BytesIO()
    df.to_excel(buffer, index=False)
    buffer.seek(0)
    return send_file(
        buffer,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name='ddos_template.xlsx',
    )


@app.route('/download/sample')
@login_required
def download_sample():
    filepath = os.path.join(os.path.dirname(__file__), 'sample_test_data.xlsx')
    if not os.path.exists(filepath):
        return 'Sample file not found', 404
    return send_file(filepath, as_attachment=True, download_name='sample_test_data.xlsx')


@app.route('/suggestion')
@login_required
def suggestion():
    uid = session['user_id']
    dash = get_dashboard_data(uid)
    counts = dash['prediction_counts']
    last_prediction = 'DDoS' if counts['DDoS'] > counts['Normal'] else 'Normal'

    if last_prediction == 'DDoS':
        suggestions = [
            '🔴 Monitor abnormal traffic spikes and alert your team immediately.',
            '🔴 Use IP blacklisting to restrict suspicious sources.',
            '🔴 Apply rate-limiting policies.',
            '🔴 Enable deep packet inspection for sensitive applications.',
            '🔴 Consider geo-blocking for known malicious regions.',
        ]
    else:
        suggestions = [
            '🟢 Network appears stable. Continue monitoring.',
            '🟢 Maintain your firewall and IDS configurations.',
            '🟢 Keep security patches up to date.',
            '🟢 Schedule regular vulnerability scans.',
            '🟢 Educate users on phishing and social engineering.',
        ]

    return render_template('suggestion.html', suggestions=suggestions)


if __name__ == '__main__':
    app.run(debug=True)
